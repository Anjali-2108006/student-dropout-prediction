"""
NetSage AI — Deterministic Rule Checker (skeleton)

This script performs rule-based checks on show-command output that are
independent of the AI diagnosis. It should catch common config mistakes
before or after the AI runs, so the human reviewer has a second, non-AI
signal to compare against.

Fill in each function once you have real show-command output formats from
your Packet Tracer labs. Each function should return a list of findings
(strings) — empty list means no issue found.
"""

from typing import List


def check_duplicate_ips(show_ip_arp_output: str) -> List[str]:
    """Flag if the same IP address appears mapped to more than one MAC address."""
    findings = []
    # TODO: parse `show ip arp` style output, group by IP, flag duplicates
    return findings


def check_wrong_mask(interface_configs: dict) -> List[str]:
    """Flag interfaces whose subnet mask doesn't match the rest of the VLAN/subnet."""
    findings = []
    # TODO: compare masks across interfaces expected to be on the same subnet
    return findings


def check_gateway_mismatch(pc_configs: dict, router_configs: dict) -> List[str]:
    """Flag PCs whose configured default gateway isn't a live interface on the router."""
    findings = []
    # TODO: compare each PC's gateway IP against router interface IPs
    return findings


def check_interface_down(show_ip_interface_brief_output: str) -> List[str]:
    """Flag interfaces reporting down/down or administratively down."""
    findings = []
    # TODO: parse `show ip interface brief`, flag any status/protocol not "up"
    return findings


def check_missing_vlan(switch_vlan_output: str, expected_vlans: list) -> List[str]:
    """Flag VLANs referenced in the topology that don't exist on the switch."""
    findings = []
    # TODO: parse `show vlan brief`, compare against expected_vlans
    return findings


def check_missing_routes(show_ip_route_output: str, expected_subnets: list) -> List[str]:
    """Flag expected destination subnets with no matching route entry."""
    findings = []
    # TODO: parse `show ip route`, compare against expected_subnets
    return findings


def run_all_checks(case: dict) -> List[str]:
    """
    Run all checks against a single case dict (loaded from a cases.csv row
    plus its raw show-command outputs) and return a combined findings list.
    """
    findings = []
    # Example wiring once the functions above are filled in:
    # findings += check_interface_down(case.get("show_ip_interface_brief", ""))
    # findings += check_missing_routes(case.get("show_ip_route", ""), case.get("expected_subnets", []))
    return findings


if __name__ == "__main__":
    # Sample usage once real data is available:
    sample_case = {
        "case_id": "CASE-001",
        # "show_ip_interface_brief": "...",
        # "show_ip_route": "...",
    }
    results = run_all_checks(sample_case)
    print(f"Findings for {sample_case['case_id']}: {results if results else 'none'}")
