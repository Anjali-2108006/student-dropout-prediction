# NetSage AI — Solution Starter Kit

This is the **initial project scaffold** for NetSage AI: an AI-assisted troubleshooting
helper for Cisco-style Packet Tracer lab networks, with mandatory human review.

This is not the finished solution — it is the structure we will fill in as we build
the project, matching the deliverables in the problem statement:

| Folder | Deliverable it becomes | Status |
|---|---|---|
| `cases/` | `cases.csv` — 30+ troubleshooting cases | Template only — cases to be collected in Packet Tracer |
| `prompts/` | `diagnose_prompt.md` — structured AI diagnosis prompt | Draft template ready |
| `checker/` | Python rule-based validation script | Skeleton with function stubs |
| `dashboard/` | Dashboard build prompt (for Lovable / Antigravity) | Draft prompt ready |

## Planned workflow

1. Collect 30+ real lab cases in Packet Tracer covering VLAN, gateway, DHCP, DNS,
   routing, ACL, NAT, and wireless faults.
2. Fill in `cases/cases_template.csv` with real symptom / show-output / expected-fault data.
3. Use `prompts/diagnose_prompt.md` to get structured JSON diagnoses (root cause,
   confidence, evidence, next command, fix) from the AI for each case.
4. Run `checker/rule_checker.py` for deterministic checks alongside the AI diagnosis
   (duplicate IPs, wrong masks, gateway mismatch, interface down, missing VLAN,
   missing routes).
5. Human review: mark each AI diagnosis Accepted / Edited / Rejected, and log at
   least 5 corrected cases with an explanation (Responsible AI log).
6. Build the dashboard (see `dashboard/dashboard_build_prompt.txt`) and record a
   5–10 minute demo video of one case going through the full pipeline.

## Team

_Add team member names and roles here._
